package com.example.MSImpresion.controller;

import com.example.MSImpresion.dto.PrestamoResponseDto;
import com.example.MSImpresion.service.impresionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/prestamos")
public class impresionController {

    @Autowired
    private impresionService impresionService;

    @GetMapping("/{id}")
    public ResponseEntity<PrestamoResponseDto> buscarPrestamoPorId(@PathVariable Long id) {
        PrestamoResponseDto prestamo = impresionService.obtenerPorId(id);
        return ResponseEntity.ok(prestamo);
    }
}