package com.example.MSImpresion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsImpresionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsImpresionApplication.class, args);
	}

}
