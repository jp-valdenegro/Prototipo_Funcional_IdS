package com.example.MSImpresion.client;

import com.example.MSImpresion.model.Inventario;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class MenorClient {

    private final WebClient inventarioWebClient;

    public MenorClient(WebClient inventarioWebClient) {
        this.inventarioWebClient = inventarioWebClient;
    }

    public Mono<InventarioDTO> obtenerItemInventario(Long inventarioId) {
        return this.inventarioWebClient.get()
                .uri("/{id}", inventarioId)
                .retrieve()
                .bodyToMono(InventarioDTO.class)
                // Si el item no existe o falla, retorna un Mono vacío controlado
                .onErrorResume(e -> Mono.empty());
    }
}