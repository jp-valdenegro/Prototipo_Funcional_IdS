package com.example.MSImpresion.model;

import lombok.Data;
import java.time.LocalDate;

@Data
public class ImpresionDetalle {
    private Long prestamoId;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucionMaxima;
    private String estado;

    // Información agregada desde los otros microservicios
    private Long libroId;
    private String tituloLibro;
    private String codigoBarraEjemplar;
}