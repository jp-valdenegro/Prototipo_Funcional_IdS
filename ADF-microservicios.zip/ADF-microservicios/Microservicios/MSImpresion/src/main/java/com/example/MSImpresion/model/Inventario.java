package com.example.MSImpresion.model;

import lombok.Data;

@Data
public class Inventario {
    private Long id;
    private Long libroId;
    private String codigoBarra;
}
