package com.example.MSImpresion.repository;


import com.example.MSImpresion.model.Impresion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface impresionRepository extends JpaRepository<Impresion, Long> {
    List<Impresion> findByUsuarioId(Long usuarioId);
}