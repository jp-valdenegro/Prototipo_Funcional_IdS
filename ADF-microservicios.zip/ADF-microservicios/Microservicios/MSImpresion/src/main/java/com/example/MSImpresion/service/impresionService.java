package com.example.MSImpresion.service;


import com.example.MSImpresion.client.VehiculoClient;
import com.example.MSImpresion.client.MenorClient;
import com.example.MSImpresion.model.*;
import com.example.MSImpresion.repository.impresionRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class PrestamoService {

    private final impresionRepository impresionRepository;
    private final MenorClient inventarioClient;
    private final VehiculoClient catalogoClient;

    public PrestamoService(impresionRepository impresionRepository,
                           MenorClient inventarioClient,
                           VehiculoClient catalogoClient) {
        this.impresionRepository = impresionRepository;
        this.inventarioClient = inventarioClient;
        this.catalogoClient = catalogoClient;
    }

    public Mono<UsuarioPrestamos> obtenerHistorialUsuario(Long usuarioId, String email, String nombre) {
        // 1. Obtener la lista de préstamos locales desde el repositorio JPA
        List<Impresion> prestamosLocales = impresionRepository.findByUsuarioId(usuarioId);

        // 2. Procesar la lista de manera reactiva y no bloqueante
        return Flux.fromIterable(prestamosLocales)
                .flatMap(prestamo -> {
                    // Inicializar el DTO individual de detalle
                    ImpresionDetalle detalle = new ImpresionDetalle();
                    detalle.setPrestamoId(prestamo.getId());
                    detalle.setFechaPrestamo(prestamo.getFechaPrestamo());
                    detalle.setFechaDevolucionMaxima(prestamo.getFechaDevolucionMaxima());
                    detalle.setEstado(prestamo.getEstado());

                    // Invocar de manera reactiva al cliente de Inventario
                    return inventarioClient.obtenerItemInventario(prestamo.getInventarioId())
                            .flatMap(inv -> {
                                detalle.setCodigoBarraEjemplar(inv.getCodigoBarra());
                                detalle.setLibroId(inv.getLibroId());

                                // Anidar la llamada a Catálogo usando el ID obtenido de Inventario
                                return catalogoClient.obtenerDatosLibro(inv.getLibroId())
                                        .map(libro -> {
                                            detalle.setTituloLibro(libro.getTitulo());
                                            return detalle;
                                        })
                                        // Si Catálogo falla, salvamos el flujo con datos parciales
                                        .defaultIfEmpty(detalle);
                            })
                            // Si Inventario falla por completo, asignamos valores por defecto
                            .defaultIfEmpty(detalle)
                            .doOnNext(d -> {
                                if (d.getTituloLibro() == null) {
                                    d.setTituloLibro("Información de catálogo no disponible");
                                }
                            });
                })
                .collectList() // Reunimos todos los hilos procesados asíncronamente en una Lista reactiva
                .map(listaDetalles -> {
                    // 3. Construir e integrar todo en el DTO raíz del Usuario
                    UsuarioPrestamos usuarioDTO = new UsuarioPrestamos();
                    usuarioDTO.setUsuarioId(usuarioId);
                    usuarioDTO.setEmail(email);
                    usuarioDTO.setNombreCompleto(nombre);
                    usuarioDTO.setPrestamos(listaDetalles);
                    return usuarioDTO;
                });
    }
}