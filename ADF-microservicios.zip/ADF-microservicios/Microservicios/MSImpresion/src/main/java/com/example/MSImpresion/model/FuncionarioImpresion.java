package com.example.MSImpresion.model;

import lombok.Data;
import java.util.List;

@Data
public class UsuarioPrestamos {
    private Long usuarioId;
    private String email;
    private String nombreCompleto;

    // La lista solicitada que contendrá la información estructurada
    private List<ImpresionDetalle> prestamos;
}