package com.example.MSImpresion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPrestamoApplicationTests {

	@Test
	void contextLoads() {
	}

}
