package com.example.MSVehiculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCatalogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
