package com.example.MSVehiculo.repository;

import com.example.MSVehiculo.model.TipoVehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TipoVehiculoRepository extends JpaRepository<TipoVehiculo, Long> {
    // Hereda todos los métodos de JPA para la tabla categorias
}