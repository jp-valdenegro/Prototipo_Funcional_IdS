package com.example.MSVehiculo.repository;

import com.example.MSVehiculo.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {
    // Hereda todos los métodos de JPA para la tabla autores
}