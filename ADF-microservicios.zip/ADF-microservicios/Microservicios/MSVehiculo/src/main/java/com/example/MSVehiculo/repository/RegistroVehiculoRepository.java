package com.example.MSVehiculo.repository;

import com.example.MSVehiculo.model.RegistroVehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RegistroVehiculoRepository extends JpaRepository<RegistroVehiculo, Long> {
    // Hereda todos los métodos de JPA para la tabla libros
}
