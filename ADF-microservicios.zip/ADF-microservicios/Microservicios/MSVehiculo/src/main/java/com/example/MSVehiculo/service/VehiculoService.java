package com.example.MSVehiculo.service;

import com.example.MSVehiculo.model.Vehiculo;
import com.example.MSVehiculo.model.TipoVehiculo;
import com.example.MSVehiculo.model.RegistroVehiculo;
import com.example.MSVehiculo.repository.VehiculoRepository;
import com.example.MSVehiculo.repository.TipoVehiculoRepository;
import com.example.MSVehiculo.repository.RegistroVehiculoRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Slf4j
@Service
public class VehiculoService {

    @Autowired
    private RegistroVehiculoRepository libroRepository;

    @Autowired
    private VehiculoRepository autorRepository;

    @Autowired
    private TipoVehiculoRepository categoriaRepository;

    // Listar todo el catálogo con Joins automáticos de JPA
    public List<RegistroVehiculo> obtenerCatalogoCompleto() {
        log.info("pasando");
        return libroRepository.findAll();
    }

    // Buscar un libro por ID
    public RegistroVehiculo obtenerPorId(Long id) {
        return libroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("RegistroVehiculo no encontrado en el catálogo con ID: " + id));
    }

    // Guardar libro verificando que existan sus relaciones JPA
    public RegistroVehiculo guardarLibroEnCatalogo(RegistroVehiculo libro) {
        if (libro.getAutor() == null || libro.getAutor().getId() == null) {
            throw new RuntimeException("El libro debe incluir un objeto autor con un ID válido.");
        }
        if (libro.getCategoria() == null || libro.getCategoria().getId() == null) {
            throw new RuntimeException("El libro debe incluir un objeto categoría con un ID válido.");
        }

        // Buscar el autor real en la base de datos
        Vehiculo autorExistente = autorRepository.findById(libro.getAutor().getId())
                .orElseThrow(() -> new RuntimeException("Error: El Vehiculo con ID " + libro.getAutor().getId() + " no existe en la base de datos."));

        // Buscar la categoría real en la base de datos
        TipoVehiculo categoriaExistente = categoriaRepository.findById(libro.getCategoria().getId())
                .orElseThrow(() -> new RuntimeException("Error: La Categoría con ID " + libro.getCategoria().getId() + " no existe en la base de datos."));

        // Establecer las relaciones JPA en el objeto RegistroVehiculo
        libro.setAutor(autorExistente);
        libro.setCategoria(categoriaExistente);

        return libroRepository.save(libro);
    }

    // Métodos para guardar autores y categorías independientes
    public Vehiculo guardarAutor(Vehiculo autor) {
        return autorRepository.save(autor);
    }

    public TipoVehiculo guardarCategoria(TipoVehiculo categoria) {
        return categoriaRepository.save(categoria);
    }
}