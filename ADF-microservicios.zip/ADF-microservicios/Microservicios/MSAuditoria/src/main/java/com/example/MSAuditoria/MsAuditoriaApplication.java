package com.example.MSAuditoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAuditoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAuditoriaApplication.class, args);
	}

}
