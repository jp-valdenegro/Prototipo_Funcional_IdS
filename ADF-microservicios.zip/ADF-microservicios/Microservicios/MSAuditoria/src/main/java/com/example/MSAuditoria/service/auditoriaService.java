package com.example.MSAuditoria.service;

import com.example.MSAuditoria.dto.VehiculoDto;
import com.example.MSAuditoria.dto.AuditoriaResponseDto;
import com.example.MSAuditoria.dto.FuncionarioDto;
import com.example.MSAuditoria.model.Auditoria;
import com.example.MSAuditoria.repository.auditoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class auditoriaService {

    @Autowired
    private auditoriaRepository auditoriaRepository;

    @Autowired
    private RestTemplate restTemplate;

    public AuditoriaResponseDto obtenerPorId(Long id) {

        Auditoria reserva = auditoriaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Auditoria no encontrada con el ID: " + id));


        FuncionarioDto usuario = null;
        try {
            String urlUsuarios = "http://localhost:8080/api/v1/usuarios/" + reserva.getUsuarioId();
            usuario = restTemplate.getForObject(urlUsuarios, FuncionarioDto.class);
        } catch (Exception e) {
            usuario = new FuncionarioDto();
            usuario.setId(reserva.getUsuarioId());
            usuario.setNombre("Usuario No disponible");
            usuario.setEmail("(Error de comunicación)");
        }

        VehiculoDto libro = null;
        try {
            String urlLibros = "http://localhost:8081/api/v1/libros/" + reserva.getLibroId();
            libro = restTemplate.getForObject(urlLibros, VehiculoDto.class);
        } catch (Exception e) {
            libro = new VehiculoDto();
            libro.setId(reserva.getLibroId());
            libro.setTitulo("Libro No disponible");
            libro.setIsbn("(Error de comunicación)");
        }

        AuditoriaResponseDto response = new AuditoriaResponseDto();
        response.setId(reserva.getId());
        response.setFechaReserva(reserva.getFechaReserva());
        response.setPosicionFila(reserva.getPosicionFila());
        response.setEstado(reserva.getEstado());
        response.setUsuario(usuario);
        response.setLibro(libro);

        return response;
    }
}