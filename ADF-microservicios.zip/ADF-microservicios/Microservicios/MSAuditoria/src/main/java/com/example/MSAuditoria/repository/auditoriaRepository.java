package com.example.MSAuditoria.repository;

import com.example.MSAuditoria.model.Auditoria;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface auditoriaRepository extends JpaRepository<Auditoria, Long> {
    // Para ver las reservas activas de un libro específico
    List<Auditoria> findByLibroIdAndEstado(Long libroId, String estado);

    // Para ver las reservas de un usuario
    List<Auditoria> findByUsuarioId(Long usuarioId);
}