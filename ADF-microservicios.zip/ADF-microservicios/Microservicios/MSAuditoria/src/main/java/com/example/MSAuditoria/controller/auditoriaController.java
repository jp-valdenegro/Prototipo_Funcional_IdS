package com.example.MSAuditoria.controller;

import com.example.MSAuditoria.dto.AuditoriaResponseDto;
import com.example.MSAuditoria.service.auditoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/reservas")
public class auditoriaController {

    @Autowired
    private auditoriaService auditoriaService;

    @GetMapping("/{id}")
    public ResponseEntity<AuditoriaResponseDto> buscarReservaPorId(@PathVariable Long id) {
        AuditoriaResponseDto reserva = auditoriaService.obtenerPorId(id);
        return ResponseEntity.ok(reserva);
    }
}