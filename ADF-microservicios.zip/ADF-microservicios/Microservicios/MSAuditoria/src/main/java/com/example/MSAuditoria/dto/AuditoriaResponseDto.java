package com.example.MSAuditoria.dto;

import java.time.LocalDateTime;

public class AuditoriaResponseDto {
    private Long id;
    private LocalDateTime fechaReserva;
    private Integer posicionFila;
    private String estado;
    private FuncionarioDto usuario;
    private VehiculoDto libro; //

    public AuditoriaResponseDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getFechaReserva() { return fechaReserva; }
    public void setFechaReserva(LocalDateTime fechaReserva) { this.fechaReserva = fechaReserva; }

    public Integer getPosicionFila() { return posicionFila; }
    public void setPosicionFila(Integer posicionFila) { this.posicionFila = posicionFila; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public FuncionarioDto getUsuario() { return usuario; }
    public void setUsuario(FuncionarioDto usuario) { this.usuario = usuario; }

    public VehiculoDto getLibro() { return libro; }
    public void setLibro(VehiculoDto libro) { this.libro = libro; }
}