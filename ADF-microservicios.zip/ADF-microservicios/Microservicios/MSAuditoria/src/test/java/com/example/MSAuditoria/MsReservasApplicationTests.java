package com.example.MSAuditoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsReservasApplicationTests {

	@Test
	void contextLoads() {
	}

}
