package com.example.MSSync.controller;


import com.example.MSSync.model.SyncEstado;
import com.example.MSSync.service.syncService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/notificaciones")
public class syncController {

    @Autowired
    private syncService service;

    @GetMapping
    public List<SyncEstado> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SyncEstado> findById(@PathVariable Long id) {
        SyncEstado notificacion = service.findById(id);
        return notificacion != null ? ResponseEntity.ok(notificacion) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<SyncEstado> save(@Valid @RequestBody SyncEstado notificacion) {
        return new ResponseEntity<>(service.save(notificacion), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
