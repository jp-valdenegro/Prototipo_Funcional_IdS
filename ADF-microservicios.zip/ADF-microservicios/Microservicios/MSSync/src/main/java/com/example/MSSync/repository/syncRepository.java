package com.example.MSSync.repository;

import com.example.MSSync.model.SyncEstado;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface syncRepository extends JpaRepository<SyncEstado, Long> {
    List<SyncEstado> findByUsuarioId(Long usuarioId);
}