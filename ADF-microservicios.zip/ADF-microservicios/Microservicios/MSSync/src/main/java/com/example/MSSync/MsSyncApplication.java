package com.example.MSSync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsSyncApplication.class, args);
	}

}
