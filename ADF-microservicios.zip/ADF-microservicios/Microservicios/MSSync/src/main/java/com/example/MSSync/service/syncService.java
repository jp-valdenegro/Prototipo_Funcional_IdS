package com.example.MSSync.service;


import com.example.MSSync.model.SyncEstado;
import com.example.MSSync.repository.syncRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.time.LocalDateTime;

@Service
@Slf4j
public class syncService {

    @Autowired
    private syncRepository repository;

    public List<SyncEstado> findAll() {
        log.info("Obteniendo lista de todas las notificaciones.");
        return repository.findAll();
    }

    public SyncEstado findById(Long id) {
        log.info("buscando notificacion por id.");
        return repository.findById(id).orElse(null);
    }

    public SyncEstado save(SyncEstado notificacion) {
        log.info("Guardando y enviando notificación.");
        if (notificacion.getFechaEnvio() == null) {
            notificacion.setFechaEnvio(LocalDateTime.now());
        }
        return repository.save(notificacion);
    }

    public void delete(Long id) {
        log.info("eliminando la notificación seleccionada.");
        repository.deleteById(id);
    }
}