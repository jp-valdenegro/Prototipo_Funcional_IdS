package com.example.MSFuncionario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MSFuncionarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
