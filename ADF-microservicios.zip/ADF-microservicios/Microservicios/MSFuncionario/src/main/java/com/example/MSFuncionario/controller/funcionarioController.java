package com.example.MSFuncionario.controller;

import com.example.MSFuncionario.client.AuthFuncionarioClient;
import com.example.MSFuncionario.model.Funcionario;
import com.example.MSFuncionario.service.funcionarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
public class funcionarioController {

    private final AuthFuncionarioClient authClient;
    @Autowired
    private funcionarioService service;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    @PostFilter("hasRole('ADMIN') or filterObject.rol == 'USUARIO'")
    public List<Funcionario> findAll() {
        return service.findAll();
    }


    @GetMapping("/id/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    @PostFilter("hasRole('ADMIN') or filterObject.rol == 'USUARIO'")
    public ResponseEntity<Funcionario> findById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public Mono<ResponseEntity<Funcionario>> save(@RequestBody Funcionario usuario) {
        return authClient.obtenerUsuario(usuario.getIdAuth())
                .map(usuario1 -> {
                    Funcionario guardado = service.save(usuario);
                    return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
                });

    }

    public ResponseEntity<Optional<Funcionario>> findByEmail(@PathVariable String email) {

        return ResponseEntity.ok(service.findByEmail(email));

    }
}