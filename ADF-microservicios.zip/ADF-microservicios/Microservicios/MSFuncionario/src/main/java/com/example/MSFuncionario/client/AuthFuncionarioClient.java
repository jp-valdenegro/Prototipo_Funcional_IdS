package com.example.MSFuncionario.client;

import com.example.MSFuncionario.model.authFuncionario;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthFuncionarioClient {
    private final WebClient webClient;
    public Mono<authFuncionario> obtenerUsuario(Long id) {
        log.info("1.");
        return webClient.get()
                .uri("/id/{id}", id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Funcionario no encontrado"
                        ))
                )
                .bodyToMono(authFuncionario.class);

    }
}
