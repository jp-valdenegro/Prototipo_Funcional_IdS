package com.example.MSFuncionario.model;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class authFuncionario {
    private Long id;

    private String email;

    private String username;

    private String password;

    private String rol;

    private Boolean activo;
}