package com.example.MSFuncionario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MSFuncionarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MSFuncionarioApplication.class, args);
	}

}
