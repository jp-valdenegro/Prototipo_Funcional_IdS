package com.example.MSFuncionario.service;

import com.example.MSFuncionario.model.Funcionario;
import com.example.MSFuncionario.repository.funcionarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
@Slf4j
public class funcionarioService {
    @Autowired
    private funcionarioRepository repository;


    public List<Funcionario> findAll() {
        log.info("Obteniendo lista de todos los usuarios.");
        return repository.findAll();
    }

    public Funcionario findById(Long id) {
        log.info("buscando usuario por id.");
        return repository.findById(id).get();
    }


    public Funcionario save(Funcionario usuario) {
        log.info("Guardando el usuario.");
        return repository.save(usuario);
    }

    public Optional<Funcionario> findByEmail(String email) {
        log.info("buscando usuario por email.");
        return repository.findByEmail(email);
    }
}



