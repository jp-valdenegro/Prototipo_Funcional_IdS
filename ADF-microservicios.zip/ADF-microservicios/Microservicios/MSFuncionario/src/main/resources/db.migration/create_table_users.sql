
INSERT INTO usuarios (email, rol, apellido1, apellido2, celular, nombre1, nombre2) VALUES
-- Administrador Central
('carlos.perez@universidad.edu', 'ADMIN', 'Pérez', 'Galdámez', 987654321, 'Carlos', 'Andrés'),

-- Trabajadores de la Biblioteca (Bibliotecarios / Personal Administrativo)
('luis.rodriguez@universidad.edu', 'TRABAJADOR', 'Rodríguez', 'Pinto', 922334455, 'Luis', 'Alberto'),
('marta.silva@universidad.edu', 'TRABAJADOR', 'Silva', 'Carcamo', 966778899, 'Marta', NULL), -- Campo nombre2 como NULL

-- Usuarios regulares (Estudiantes)
('diego.munoz@alumnos.universidad.edu', 'USUARIO', 'Muñoz', 'Arancibia', 944556677, 'Diego', 'Ignacio'),
('sofia.tapia@alumnos.universidad.edu', 'USUARIO', 'Tapia', 'Morales', 988990011, 'Sofía', 'Valentina'),
('lucas.contreras@alumnos.universidad.edu', 'USUARIO', 'Contreras', 'Vergara', 977889900, 'Lucas', NULL), -- Campo nombre2 como NULL
('camila.fuentes@alumnos.universidad.edu', 'USUARIO', 'Fuentes', 'Soto', 911223344, 'Camila', 'Fernanda');
