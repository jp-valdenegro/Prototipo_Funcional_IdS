package com.example.MSMenor.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventario")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Menor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "libro_id", nullable = false)
    private Long libroId; // ID lógico que conecta con MSCatalogo

    @Column(name = "codigo_barra", nullable = false, unique = true)
    private String codigoBarra;

    @Column(nullable = false, length = 50)
    private String estado; // "DISPONIBLE", "PRESTADO", "MANTENIMIENTO"
}