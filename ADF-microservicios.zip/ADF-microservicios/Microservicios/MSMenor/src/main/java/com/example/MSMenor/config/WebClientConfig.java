package com.example.MSMenor.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient catalogoWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8083/api/v1/libros")
                .build();
    }
}
