package com.example.MSMenor.model;

import lombok.Data;

@Data
public class Libro {
    private Long id;
    private String titulo;
}
