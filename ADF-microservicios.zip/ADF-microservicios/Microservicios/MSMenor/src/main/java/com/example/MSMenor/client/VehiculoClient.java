package com.example.MSMenor.client;

import com.example.MSMenor.model.*;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class VehiculoClient {

    private final WebClient catalogoWebClient;

    public VehiculoClient(WebClient catalogoWebClient) {
        this.catalogoWebClient = catalogoWebClient;
    }

    public Mono<Libro> obtenerDatosLibro(Long libroId) {
        return this.catalogoWebClient.get()
                .uri("/{id}", libroId)
                .retrieve()
                .bodyToMono(Libro.class)
                // Si el libro no existe (404) o hay error, retorna un Mono vacío controlado
                .onErrorResume(e -> Mono.empty());
    }
}