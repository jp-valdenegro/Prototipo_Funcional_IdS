package com.example.MSMenor.repository;


import com.example.MSMenor.model.Menor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface menorRepository extends JpaRepository<Menor, Long> {
    // Para que el MSPrestamos o MSReservas valide si un código de barra específico está libre
    java.util.Optional<Menor> findByCodigoBarra(String codigoBarra);
}