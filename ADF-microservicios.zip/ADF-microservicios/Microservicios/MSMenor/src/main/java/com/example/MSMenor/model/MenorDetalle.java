package com.example.MSMenor.model;

import lombok.Data;

@Data
public class MenorDetalle {
    private Long inventarioId;
    private Long libroId;
    private String tituloLibro;
    private String codigoBarra;
    private String estado;
}