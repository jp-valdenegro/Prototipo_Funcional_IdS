package com.example.MSMenor.controller;

import com.example.MSMenor.model.Menor;
import com.example.MSMenor.service.menorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/inventario")
public class menorController {

    @Autowired
    private menorService service;

    @GetMapping
    public List<Menor> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Menor> findById(@PathVariable Long id) {
        Menor inventario = service.findById(id);
        return inventario != null ? ResponseEntity.ok(inventario) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Menor> save(@Valid @RequestBody Menor inventario) {
        return new ResponseEntity<>(service.save(inventario), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}