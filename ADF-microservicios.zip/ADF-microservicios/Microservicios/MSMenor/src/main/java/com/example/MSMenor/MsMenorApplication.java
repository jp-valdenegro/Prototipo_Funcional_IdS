package com.example.MSMenor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsMenorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsMenorApplication.class, args);
	}

}
