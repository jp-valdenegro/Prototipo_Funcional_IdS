package com.example.MSMenor.service;

import com.example.MSMenor.client.VehiculoClient;
import com.example.MSMenor.model.*;
import com.example.MSMenor.model.Menor;
import com.example.MSMenor.repository.menorRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class menorService {

    private final menorRepository menorRepository;
    private final VehiculoClient catalogoClient;

    public menorService(menorRepository menorRepository, VehiculoClient catalogoClient) {
        this.menorRepository = menorRepository;
        this.catalogoClient = catalogoClient;
    }

    // 1. Obtener un ítem de inventario unificado con los datos de Catálogo
    public Mono<MenorDetalle> obtenerItemConCatalogo(Long id) {
        return Mono.justOrEmpty(menorRepository.findById(id))
                .flatMap(item -> {
                    MenorDetalle dto = new MenorDetalle();
                    dto.setInventarioId(item.getId());
                    dto.setLibroId(item.getLibroId());
                    dto.setCodigoBarra(item.getCodigoBarra());
                    dto.setEstado(item.getEstado());

                    // Llamada al Microservicio de Catálogo
                    return catalogoClient.obtenerDatosLibro(item.getLibroId())
                            .map(libro -> {
                                dto.setTituloLibro(libro.getTitulo());
                                return dto;
                            })
                            // Si el catálogo está caído, no rompemos el flujo de inventario por completo
                            .defaultIfEmpty(dto);
                })
                .doOnNext(dto -> {
                    if (dto.getTituloLibro() == null) {
                        dto.setTituloLibro("Título no disponible temporalmente");
                    }
                });
    }

    // 2. Crear Ejemplar VALIDANDO que el libro exista en Catálogo (Como en tu guía)
    public Mono<Menor> guardarEjemplar(Menor nuevoItem) {
        return catalogoClient.obtenerDatosLibro(nuevoItem.getLibroId())
                // Si el Mono viene vacío significa que el libro no existe en MSCatalogo
                .switchIfEmpty(Mono.error(new RuntimeException("Error: El id de libro " + nuevoItem.getLibroId() + " no existe en el Catálogo.")))
                .map(libroDto -> {
                    // Si existía, procedemos a guardar físicamente en el inventario local
                    return menorRepository.save(nuevoItem);
                });
    }

    // 3. Modificar Estado (Invocado por MSPrestamos cuando alguien pide o devuelve un libro)
    public Mono<Menor> actualizarEstado(Long id, String nuevoEstado) {
        return Mono.justOrEmpty(menorRepository.findById(id))
                .map(item -> {
                    item.setEstado(nuevoEstado);
                    return menorRepository.save(item);
                })
                .switchIfEmpty(Mono.error(new RuntimeException("Item de inventario no encontrado")));
    }
}