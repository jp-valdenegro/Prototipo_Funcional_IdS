package com.example.MSDeclaracion.controller;

import com.example.MSDeclaracion.model.Declaracion;
import com.example.MSDeclaracion.service.declaracionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/multas")
public class declaracionController {

    @Autowired
    private declaracionService service;

    @GetMapping
    public List<Declaracion> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Declaracion> findById(@PathVariable Long id) {
        Declaracion multa = service.findById(id);
        return multa != null ? ResponseEntity.ok(multa) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Declaracion> save(@Valid @RequestBody Declaracion multa) {
        return new ResponseEntity<>(service.save(multa), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
