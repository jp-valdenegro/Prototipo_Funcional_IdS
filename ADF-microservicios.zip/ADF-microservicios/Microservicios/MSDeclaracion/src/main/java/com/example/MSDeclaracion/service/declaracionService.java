package com.example.MSDeclaracion.service;


import com.example.MSDeclaracion.model.Declaracion;
import com.example.MSDeclaracion.repository.declaracionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class declaracionService {

    @Autowired
    private declaracionRepository repository;

    public List<Declaracion> findAll() {
        log.info("Obteniendo lista de todas las multas.");
        return repository.findAll();
    }

    public Declaracion findById(Long id) {
        log.info("buscando multa por id.");
        return repository.findById(id).orElse(null);
    }

    public Declaracion save(Declaracion multa) {
        log.info("Guardando la multa.");
        if (multa.getFechaGeneracion() == null) {
            multa.setFechaGeneracion(LocalDateTime.now());
        }
        return repository.save(multa);
    }

    public void delete(Long id) {
        log.info("eliminando la multa seleccionada.");
        repository.deleteById(id);
    }
}