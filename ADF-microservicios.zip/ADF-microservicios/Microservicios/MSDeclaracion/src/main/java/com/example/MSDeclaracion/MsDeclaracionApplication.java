package com.example.MSDeclaracion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsDeclaracionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsDeclaracionApplication.class, args);
	}

}
