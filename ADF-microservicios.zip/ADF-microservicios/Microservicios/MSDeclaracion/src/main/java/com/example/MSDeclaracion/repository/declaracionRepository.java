package com.example.MSDeclaracion.repository;


import com.example.MSDeclaracion.model.Declaracion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface declaracionRepository extends JpaRepository<Declaracion, Long> {
    List<Declaracion> findByUsuarioId(Long usuarioId);
}
