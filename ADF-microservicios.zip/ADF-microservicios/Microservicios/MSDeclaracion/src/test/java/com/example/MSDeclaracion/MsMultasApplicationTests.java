package com.example.MSDeclaracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMultasApplicationTests {

	@Test
	void contextLoads() {
	}

}
