package com.example.MSReporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsReportesApplicationTests {

	@Test
	void contextLoads() {
	}

}
